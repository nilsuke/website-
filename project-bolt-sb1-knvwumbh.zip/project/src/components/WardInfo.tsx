import React, { useState } from 'react';
import { Bed, Wifi, Tv, Coffee, Car, CheckCircle, X } from 'lucide-react';

interface Ward {
  id: string;
  number: string;
  type: 'Private' | 'Semi-Private' | 'General';
  status: 'Available' | 'Occupied' | 'Maintenance';
  floor: number;
  amenities: string[];
  price: number;
  capacity: number;
  occupied: number;
  description: string;
}

const wards: Ward[] = [
  {
    id: '1',
    number: 'W101',
    type: 'Private',
    status: 'Available',
    floor: 1,
    amenities: ['Wi-Fi', 'TV', 'AC', 'Private Bathroom', 'Refrigerator'],
    price: 200,
    capacity: 1,
    occupied: 0,
    description: 'Luxury private room with premium amenities and city view'
  },
  {
    id: '2',
    number: 'W102',
    type: 'Private',
    status: 'Occupied',
    floor: 1,
    amenities: ['Wi-Fi', 'TV', 'AC', 'Private Bathroom'],
    price: 180,
    capacity: 1,
    occupied: 1,
    description: 'Comfortable private room with essential amenities'
  },
  {
    id: '3',
    number: 'W201',
    type: 'Semi-Private',
    status: 'Available',
    floor: 2,
    amenities: ['Wi-Fi', 'TV', 'AC', 'Shared Bathroom'],
    price: 120,
    capacity: 2,
    occupied: 1,
    description: 'Semi-private room sharing with one other patient'
  },
  {
    id: '4',
    number: 'W202',
    type: 'Semi-Private',
    status: 'Available',
    floor: 2,
    amenities: ['Wi-Fi', 'TV', 'AC', 'Shared Bathroom'],
    price: 120,
    capacity: 2,
    occupied: 0,
    description: 'Semi-private room with comfortable accommodation'
  },
  {
    id: '5',
    number: 'W301',
    type: 'General',
    status: 'Available',
    floor: 3,
    amenities: ['Wi-Fi', 'TV', 'Fan'],
    price: 80,
    capacity: 4,
    occupied: 2,
    description: 'General ward with basic amenities and nursing care'
  },
  {
    id: '6',
    number: 'W302',
    type: 'General',
    status: 'Maintenance',
    floor: 3,
    amenities: ['Wi-Fi', 'TV', 'Fan'],
    price: 80,
    capacity: 4,
    occupied: 0,
    description: 'General ward currently under maintenance'
  },
  {
    id: '7',
    number: 'W401',
    type: 'Private',
    status: 'Available',
    floor: 4,
    amenities: ['Wi-Fi', 'TV', 'AC', 'Private Bathroom', 'Balcony'],
    price: 250,
    capacity: 1,
    occupied: 0,
    description: 'Premium private room with balcony and garden view'
  },
  {
    id: '8',
    number: 'W501',
    type: 'Semi-Private',
    status: 'Available',
    floor: 5,
    amenities: ['Wi-Fi', 'TV', 'AC', 'Shared Bathroom', 'Kitchenette'],
    price: 150,
    capacity: 2,
    occupied: 0,
    description: 'Semi-private room with kitchenette facility'
  }
];

const amenityIcons: { [key: string]: React.ComponentType<{ className?: string }> } = {
  'Wi-Fi': Wifi,
  'TV': Tv,
  'AC': CheckCircle,
  'Fan': CheckCircle,
  'Private Bathroom': CheckCircle,
  'Shared Bathroom': CheckCircle,
  'Refrigerator': CheckCircle,
  'Balcony': CheckCircle,
  'Kitchenette': Coffee,
  'Parking': Car,
};

export function WardInfo() {
  const [selectedType, setSelectedType] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');

  const wardTypes = ['All', 'Private', 'Semi-Private', 'General'];
  const wardStatuses = ['All', 'Available', 'Occupied', 'Maintenance'];

  const filteredWards = wards.filter(ward => {
    const typeMatch = selectedType === 'All' || ward.type === selectedType;
    const statusMatch = selectedStatus === 'All' || ward.status === selectedStatus;
    return typeMatch && statusMatch;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Available':
        return 'text-green-700 bg-green-100';
      case 'Occupied':
        return 'text-red-700 bg-red-100';
      case 'Maintenance':
        return 'text-yellow-700 bg-yellow-100';
      default:
        return 'text-gray-700 bg-gray-100';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Private':
        return 'text-purple-700 bg-purple-100';
      case 'Semi-Private':
        return 'text-blue-700 bg-blue-100';
      case 'General':
        return 'text-gray-700 bg-gray-100';
      default:
        return 'text-gray-700 bg-gray-100';
    }
  };

  const availableWards = wards.filter(w => w.status === 'Available').length;
  const totalWards = wards.length;
  const occupancyRate = ((totalWards - availableWards) / totalWards * 100).toFixed(1);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <div className="w-16 h-16 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
          <Bed className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Ward Information</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Find available wards and check facilities across all floors
        </p>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-200">
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">{availableWards}</div>
            <div className="text-gray-600">Available Wards</div>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-200">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">{totalWards}</div>
            <div className="text-gray-600">Total Wards</div>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-200">
          <div className="text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">{occupancyRate}%</div>
            <div className="text-gray-600">Occupancy Rate</div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-200 mb-8">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">Ward Type</label>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            >
              {wardTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            >
              {wardStatuses.map(status => (
                <option key={status} value={status}>{status}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Ward Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredWards.map((ward) => (
          <div
            key={ward.id}
            className={`bg-white/80 backdrop-blur-sm rounded-2xl p-6 border-2 transition-all duration-200 hover:shadow-lg ${
              ward.status === 'Available'
                ? 'border-green-200 hover:border-green-300'
                : ward.status === 'Occupied'
                ? 'border-gray-200'
                : 'border-yellow-200'
            }`}
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-1">Ward {ward.number}</h3>
                <p className="text-sm text-gray-500">Floor {ward.floor}</p>
              </div>
              <div className="flex flex-col items-end space-y-2">
                <span className={`px-3 py-1 rounded-lg text-sm font-medium ${getStatusColor(ward.status)}`}>
                  {ward.status}
                </span>
                <span className={`px-3 py-1 rounded-lg text-sm font-medium ${getTypeColor(ward.type)}`}>
                  {ward.type}
                </span>
              </div>
            </div>

            <p className="text-gray-600 text-sm mb-4">{ward.description}</p>

            <div className="flex items-center justify-between mb-4">
              <div>
                <span className="text-sm text-gray-500">Capacity</span>
                <div className="flex items-center space-x-2">
                  <div className="flex space-x-1">
                    {Array.from({ length: ward.capacity }).map((_, i) => (
                      <Bed
                        key={i}
                        className={`h-4 w-4 ${
                          i < ward.occupied ? 'text-red-500' : 'text-green-500'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm font-medium text-gray-700">
                    {ward.occupied}/{ward.capacity}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-2xl font-bold text-indigo-600">${ward.price}</span>
                <p className="text-sm text-gray-500">per night</p>
              </div>
            </div>

            <div className="border-t border-gray-100 pt-4">
              <h4 className="text-sm font-medium text-gray-700 mb-3">Amenities</h4>
              <div className="grid grid-cols-2 gap-2">
                {ward.amenities.map((amenity) => {
                  const Icon = amenityIcons[amenity] || CheckCircle;
                  return (
                    <div key={amenity} className="flex items-center space-x-2">
                      <Icon className="h-4 w-4 text-green-500" />
                      <span className="text-sm text-gray-600">{amenity}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {ward.status === 'Available' && (
              <button className="w-full mt-4 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-200">
                Request Ward
              </button>
            )}
          </div>
        ))}
      </div>

      {filteredWards.length === 0 && (
        <div className="text-center py-12">
          <X className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">No wards found matching your criteria</p>
        </div>
      )}
    </div>
  );
}