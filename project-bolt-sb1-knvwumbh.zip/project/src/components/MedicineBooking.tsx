import React, { useState } from 'react';
import { Pill, MapPin, Clock, CheckCircle, AlertCircle } from 'lucide-react';

interface Medicine {
  id: string;
  name: string;
  dosage: string;
  price: number;
  inStock: boolean;
  description: string;
}

const medicines: Medicine[] = [
  { id: '1', name: 'Paracetamol', dosage: '500mg', price: 12, inStock: true, description: 'Pain relief and fever reducer' },
  { id: '2', name: 'Amoxicillin', dosage: '250mg', price: 35, inStock: true, description: 'Antibiotic for bacterial infections' },
  { id: '3', name: 'Ibuprofen', dosage: '400mg', price: 18, inStock: false, description: 'Anti-inflammatory medication' },
  { id: '4', name: 'Aspirin', dosage: '75mg', price: 8, inStock: true, description: 'Blood thinner and pain reliever' },
  { id: '5', name: 'Omeprazole', dosage: '20mg', price: 25, inStock: true, description: 'Acid reflux treatment' },
  { id: '6', name: 'Metformin', dosage: '500mg', price: 22, inStock: true, description: 'Diabetes medication' },
];

export function MedicineBooking() {
  const [wardNumber, setWardNumber] = useState('');
  const [selectedMedicines, setSelectedMedicines] = useState<{[key: string]: number}>({});
  const [orderPlaced, setOrderPlaced] = useState(false);

  const handleQuantityChange = (medicineId: string, quantity: number) => {
    if (quantity === 0) {
      const newSelected = { ...selectedMedicines };
      delete newSelected[medicineId];
      setSelectedMedicines(newSelected);
    } else {
      setSelectedMedicines(prev => ({
        ...prev,
        [medicineId]: quantity
      }));
    }
  };

  const getTotalPrice = () => {
    return Object.entries(selectedMedicines).reduce((total, [medicineId, quantity]) => {
      const medicine = medicines.find(m => m.id === medicineId);
      return total + (medicine ? medicine.price * quantity : 0);
    }, 0);
  };

  const handlePlaceOrder = () => {
    if (wardNumber && Object.keys(selectedMedicines).length > 0) {
      setOrderPlaced(true);
      setTimeout(() => {
        setOrderPlaced(false);
        setSelectedMedicines({});
        setWardNumber('');
      }, 3000);
    }
  };

  if (orderPlaced) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-12 text-center border border-green-200">
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-12 w-12 text-green-600" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Order Confirmed!</h2>
          <p className="text-xl text-gray-600 mb-6">
            Your medicines will be delivered to Ward {wardNumber} within 30 minutes.
          </p>
          <p className="text-lg text-gray-500">
            Total Amount: ${getTotalPrice()}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-teal-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
          <Pill className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Medicine Booking</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Order your prescribed medicines for direct delivery to your ward
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Medicine List */}
        <div className="lg:col-span-2">
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 border border-gray-200">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">Available Medicines</h2>
            <div className="grid gap-4">
              {medicines.map((medicine) => (
                <div
                  key={medicine.id}
                  className={`p-6 rounded-2xl border transition-all duration-200 ${
                    medicine.inStock
                      ? 'border-gray-200 hover:border-blue-300 hover:shadow-md'
                      : 'border-red-200 bg-red-50/50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <h3 className="text-lg font-semibold text-gray-900">
                          {medicine.name}
                        </h3>
                        <span className="text-sm text-gray-500 bg-gray-100 px-2 py-1 rounded-lg">
                          {medicine.dosage}
                        </span>
                        {medicine.inStock ? (
                          <span className="text-sm text-green-600 bg-green-100 px-2 py-1 rounded-lg flex items-center">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            In Stock
                          </span>
                        ) : (
                          <span className="text-sm text-red-600 bg-red-100 px-2 py-1 rounded-lg flex items-center">
                            <AlertCircle className="h-3 w-3 mr-1" />
                            Out of Stock
                          </span>
                        )}
                      </div>
                      <p className="text-gray-600 mt-1">{medicine.description}</p>
                      <p className="text-lg font-semibold text-blue-600 mt-2">${medicine.price}</p>
                    </div>
                    {medicine.inStock && (
                      <div className="flex items-center space-x-3">
                        <button
                          onClick={() => handleQuantityChange(medicine.id, Math.max(0, (selectedMedicines[medicine.id] || 0) - 1))}
                          className="w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-lg flex items-center justify-center text-gray-600 font-semibold transition-colors"
                        >
                          -
                        </button>
                        <span className="w-12 text-center font-semibold">
                          {selectedMedicines[medicine.id] || 0}
                        </span>
                        <button
                          onClick={() => handleQuantityChange(medicine.id, (selectedMedicines[medicine.id] || 0) + 1)}
                          className="w-10 h-10 bg-blue-100 hover:bg-blue-200 rounded-lg flex items-center justify-center text-blue-600 font-semibold transition-colors"
                        >
                          +
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 border border-gray-200 sticky top-24">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">Order Summary</h2>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ward Number *
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  value={wardNumber}
                  onChange={(e) => setWardNumber(e.target.value)}
                  placeholder="Enter your ward number"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            {Object.keys(selectedMedicines).length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Selected Items</h3>
                <div className="space-y-3">
                  {Object.entries(selectedMedicines).map(([medicineId, quantity]) => {
                    const medicine = medicines.find(m => m.id === medicineId);
                    if (!medicine) return null;
                    return (
                      <div key={medicineId} className="flex justify-between items-center py-2 border-b border-gray-100">
                        <div>
                          <p className="font-medium text-gray-900">{medicine.name}</p>
                          <p className="text-sm text-gray-500">Qty: {quantity}</p>
                        </div>
                        <p className="font-semibold text-gray-900">${medicine.price * quantity}</p>
                      </div>
                    );
                  })}
                </div>
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <div className="flex justify-between items-center">
                    <p className="text-lg font-semibold text-gray-900">Total</p>
                    <p className="text-2xl font-bold text-blue-600">${getTotalPrice()}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="mb-6">
              <div className="flex items-center space-x-2 text-sm text-gray-600 bg-blue-50 p-3 rounded-xl">
                <Clock className="h-4 w-4 text-blue-600" />
                <span>Delivery time: 20-30 minutes</span>
              </div>
            </div>

            <button
              onClick={handlePlaceOrder}
              disabled={!wardNumber || Object.keys(selectedMedicines).length === 0}
              className="w-full py-4 bg-gradient-to-r from-blue-600 to-teal-600 text-white rounded-xl font-semibold text-lg hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
            >
              Place Order
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}