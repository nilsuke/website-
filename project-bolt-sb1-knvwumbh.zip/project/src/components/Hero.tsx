import React from 'react';
import { Calendar, Pill, Bed, Users, ArrowRight } from 'lucide-react';

type Section = 'home' | 'medicine' | 'consultation' | 'wards' | 'staff';

interface HeroProps {
  onNavigate: (section: Section) => void;
}

export function Hero({ onNavigate }: HeroProps) {
  const services = [
    {
      id: 'medicine' as Section,
      icon: Pill,
      title: 'Medicine Booking',
      description: 'Order medicines directly to your ward',
      color: 'from-blue-500 to-blue-600',
    },
    {
      id: 'consultation' as Section,
      icon: Calendar,
      title: 'Doctor Consultation',
      description: 'Book video calls with specialists',
      color: 'from-teal-500 to-teal-600',
    },
    {
      id: 'wards' as Section,
      icon: Bed,
      title: 'Ward Information',
      description: 'Check vacant wards and facilities',
      color: 'from-indigo-500 to-indigo-600',
    },
    {
      id: 'staff' as Section,
      icon: Users,
      title: 'Medical Staff',
      description: 'Meet our doctors and nurses',
      color: 'from-purple-500 to-purple-600',
    },
  ];

  return (
    <div className="relative">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 via-teal-500/5 to-purple-600/10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="bg-gradient-to-r from-blue-600 via-teal-600 to-purple-600 bg-clip-text text-transparent">
                Future of
              </span>
              <br />
              <span className="text-gray-900">Healthcare</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-12 leading-relaxed">
              Experience seamless healthcare management with our advanced digital platform. 
              Book medicines, consult doctors, and access all hospital services instantly.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => onNavigate('medicine')}
                className="px-8 py-4 bg-gradient-to-r from-blue-600 to-teal-600 text-white rounded-2xl font-semibold text-lg hover:shadow-lg hover:scale-105 transition-all duration-200"
              >
                Order Medicine
              </button>
              <button
                onClick={() => onNavigate('consultation')}
                className="px-8 py-4 bg-white border-2 border-gray-200 text-gray-700 rounded-2xl font-semibold text-lg hover:border-blue-300 hover:shadow-lg hover:scale-105 transition-all duration-200"
              >
                Book Consultation
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Services Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Our Services
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Access comprehensive healthcare services through our digital platform
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <div
                key={service.id}
                onClick={() => onNavigate(service.id)}
                className="group relative bg-white/60 backdrop-blur-sm rounded-3xl p-8 border border-gray-200/50 hover:bg-white hover:shadow-xl hover:shadow-blue-500/10 cursor-pointer transition-all duration-300"
              >
                <div className={`w-16 h-16 bg-gradient-to-r ${service.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-200`}>
                  <Icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  {service.title}
                </h3>
                <p className="text-gray-600 mb-4">
                  {service.description}
                </p>
                <div className="flex items-center text-blue-600 font-medium group-hover:translate-x-1 transition-transform duration-200">
                  Learn more
                  <ArrowRight className="ml-2 h-4 w-4" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}