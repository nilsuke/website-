import React, { useState } from 'react';
import { Video, Calendar, Clock, User, Star, CheckCircle } from 'lucide-react';

interface Doctor {
  id: string;
  name: string;
  specialization: string;
  experience: number;
  rating: number;
  image: string;
  availableSlots: string[];
  price: number;
}

const doctors: Doctor[] = [
  {
    id: '1',
    name: 'Dr. Sarah Johnson',
    specialization: 'Cardiology',
    experience: 15,
    rating: 4.9,
    image: 'https://images.pexels.com/photos/5215024/pexels-photo-5215024.jpeg?auto=compress&cs=tinysrgb&w=400',
    availableSlots: ['09:00 AM', '10:30 AM', '02:00 PM', '04:30 PM'],
    price: 150,
  },
  {
    id: '2',
    name: 'Dr. Michael Chen',
    specialization: 'Neurology',
    experience: 12,
    rating: 4.8,
    image: 'https://images.pexels.com/photos/5452293/pexels-photo-5452293.jpeg?auto=compress&cs=tinysrgb&w=400',
    availableSlots: ['08:30 AM', '11:00 AM', '01:30 PM', '03:00 PM'],
    price: 180,
  },
  {
    id: '3',
    name: 'Dr. Emily Rodriguez',
    specialization: 'Pediatrics',
    experience: 10,
    rating: 4.9,
    image: 'https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg?auto=compress&cs=tinysrgb&w=400',
    availableSlots: ['09:30 AM', '11:30 AM', '02:30 PM', '05:00 PM'],
    price: 120,
  },
  {
    id: '4',
    name: 'Dr. James Wilson',
    specialization: 'Orthopedics',
    experience: 18,
    rating: 4.7,
    image: 'https://images.pexels.com/photos/6749773/pexels-photo-6749773.jpeg?auto=compress&cs=tinysrgb&w=400',
    availableSlots: ['08:00 AM', '10:00 AM', '01:00 PM', '04:00 PM'],
    price: 160,
  },
];

export function DoctorConsultation() {
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [selectedSlot, setSelectedSlot] = useState('');
  const [selectedDate, setSelectedDate] = useState('');
  const [bookingConfirmed, setBookingConfirmed] = useState(false);
  const [patientName, setPatientName] = useState('');
  const [patientPhone, setPatientPhone] = useState('');

  const handleBooking = () => {
    if (selectedDoctor && selectedSlot && selectedDate && patientName && patientPhone) {
      setBookingConfirmed(true);
      setTimeout(() => {
        setBookingConfirmed(false);
        setSelectedDoctor(null);
        setSelectedSlot('');
        setSelectedDate('');
        setPatientName('');
        setPatientPhone('');
      }, 3000);
    }
  };

  const getTomorrowDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  if (bookingConfirmed) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-12 text-center border border-green-200">
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-12 w-12 text-green-600" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Consultation Booked!</h2>
          <p className="text-xl text-gray-600 mb-4">
            Your video consultation with {selectedDoctor?.name} is confirmed
          </p>
          <p className="text-lg text-gray-500 mb-2">
            Date: {selectedDate} at {selectedSlot}
          </p>
          <p className="text-lg text-gray-500">
            You'll receive a video call link via SMS before the appointment
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <div className="w-16 h-16 bg-gradient-to-r from-teal-600 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
          <Video className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Doctor Consultation</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Book video consultations with our specialist doctors from the comfort of your ward
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Doctors List */}
        <div className="lg:col-span-2">
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 border border-gray-200">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">Available Doctors</h2>
            <div className="grid gap-6">
              {doctors.map((doctor) => (
                <div
                  key={doctor.id}
                  className={`p-6 rounded-2xl border-2 cursor-pointer transition-all duration-200 ${
                    selectedDoctor?.id === doctor.id
                      ? 'border-blue-300 bg-blue-50/50 shadow-md'
                      : 'border-gray-200 hover:border-blue-300 hover:shadow-md'
                  }`}
                  onClick={() => setSelectedDoctor(doctor)}
                >
                  <div className="flex items-start space-x-4">
                    <img
                      src={doctor.image}
                      alt={doctor.name}
                      className="w-20 h-20 rounded-xl object-cover"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="text-xl font-semibold text-gray-900">{doctor.name}</h3>
                        <div className="flex items-center space-x-1">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span className="text-sm font-medium text-gray-700">{doctor.rating}</span>
                        </div>
                      </div>
                      <p className="text-blue-600 font-medium mb-2">{doctor.specialization}</p>
                      <p className="text-gray-600 text-sm mb-3">{doctor.experience} years experience</p>
                      <div className="flex items-center justify-between">
                        <div className="flex flex-wrap gap-2">
                          {doctor.availableSlots.slice(0, 3).map((slot) => (
                            <span
                              key={slot}
                              className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-lg"
                            >
                              {slot}
                            </span>
                          ))}
                          {doctor.availableSlots.length > 3 && (
                            <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-lg">
                              +{doctor.availableSlots.length - 3} more
                            </span>
                          )}
                        </div>
                        <p className="text-lg font-bold text-blue-600">${doctor.price}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Booking Form */}
        <div className="lg:col-span-1">
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 border border-gray-200 sticky top-24">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">Book Consultation</h2>
            
            {selectedDoctor ? (
              <div className="space-y-6">
                <div className="p-4 bg-blue-50 rounded-2xl">
                  <div className="flex items-center space-x-3">
                    <img
                      src={selectedDoctor.image}
                      alt={selectedDoctor.name}
                      className="w-12 h-12 rounded-lg object-cover"
                    />
                    <div>
                      <h3 className="font-semibold text-gray-900">{selectedDoctor.name}</h3>
                      <p className="text-sm text-blue-600">{selectedDoctor.specialization}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Patient Name *
                  </label>
                  <input
                    type="text"
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    placeholder="Enter patient name"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    value={patientPhone}
                    onChange={(e) => setPatientPhone(e.target.value)}
                    placeholder="Enter phone number"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Select Date *
                  </label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    min={getTomorrowDate()}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Available Time Slots *
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {selectedDoctor.availableSlots.map((slot) => (
                      <button
                        key={slot}
                        onClick={() => setSelectedSlot(slot)}
                        className={`p-3 text-sm font-medium rounded-xl transition-all duration-200 ${
                          selectedSlot === slot
                            ? 'bg-blue-600 text-white shadow-md'
                            : 'bg-gray-100 text-gray-700 hover:bg-blue-100'
                        }`}
                      >
                        {slot}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-4 bg-gray-50 rounded-xl">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Consultation Fee</span>
                    <span className="text-2xl font-bold text-blue-600">${selectedDoctor.price}</span>
                  </div>
                </div>

                <button
                  onClick={handleBooking}
                  disabled={!selectedSlot || !selectedDate || !patientName || !patientPhone}
                  className="w-full py-4 bg-gradient-to-r from-teal-600 to-blue-600 text-white rounded-xl font-semibold text-lg hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                >
                  Book Video Consultation
                </button>

                <div className="text-center">
                  <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
                    <Video className="h-4 w-4" />
                    <span>HD Video Call • Secure & Private</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Select a doctor to book consultation</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}