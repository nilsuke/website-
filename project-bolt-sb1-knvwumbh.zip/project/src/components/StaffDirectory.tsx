import React, { useState } from 'react';
import { Users, Search, Star, Phone, Mail, Award } from 'lucide-react';

interface StaffMember {
  id: string;
  name: string;
  role: 'Doctor' | 'Nurse';
  specialization: string;
  experience: number;
  rating: number;
  image: string;
  phone: string;
  email: string;
  department: string;
  qualifications: string[];
  languages: string[];
  shift: 'Morning' | 'Evening' | 'Night';
}

const staffMembers: StaffMember[] = [
  {
    id: '1',
    name: 'Dr. Sarah Johnson',
    role: 'Doctor',
    specialization: 'Cardiology',
    experience: 15,
    rating: 4.9,
    image: 'https://images.pexels.com/photos/5215024/pexels-photo-5215024.jpeg?auto=compress&cs=tinysrgb&w=400',
    phone: '+1 (555) 123-4567',
    email: 'sarah.johnson@medcare.com',
    department: 'Cardiology',
    qualifications: ['MD', 'FACC', 'Board Certified'],
    languages: ['English', 'Spanish'],
    shift: 'Morning'
  },
  {
    id: '2',
    name: 'Nurse Emily Rodriguez',
    role: 'Nurse',
    specialization: 'ICU Care',
    experience: 8,
    rating: 4.8,
    image: 'https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg?auto=compress&cs=tinysrgb&w=400',
    phone: '+1 (555) 234-5678',
    email: 'emily.rodriguez@medcare.com',
    department: 'Intensive Care',
    qualifications: ['RN', 'BSN', 'CCRN'],
    languages: ['English', 'Spanish', 'Portuguese'],
    shift: 'Night'
  },
  {
    id: '3',
    name: 'Dr. Michael Chen',
    role: 'Doctor',
    specialization: 'Neurology',
    experience: 12,
    rating: 4.8,
    image: 'https://images.pexels.com/photos/5452293/pexels-photo-5452293.jpeg?auto=compress&cs=tinysrgb&w=400',
    phone: '+1 (555) 345-6789',
    email: 'michael.chen@medcare.com',
    department: 'Neurology',
    qualifications: ['MD', 'PhD', 'Board Certified'],
    languages: ['English', 'Mandarin'],
    shift: 'Morning'
  },
  {
    id: '4',
    name: 'Nurse Jessica Thompson',
    role: 'Nurse',
    specialization: 'Pediatric Care',
    experience: 6,
    rating: 4.9,
    image: 'https://images.pexels.com/photos/8460011/pexels-photo-8460011.jpeg?auto=compress&cs=tinysrgb&w=400',
    phone: '+1 (555) 456-7890',
    email: 'jessica.thompson@medcare.com',
    department: 'Pediatrics',
    qualifications: ['RN', 'CPN', 'BSN'],
    languages: ['English', 'French'],
    shift: 'Evening'
  },
  {
    id: '5',
    name: 'Dr. James Wilson',
    role: 'Doctor',
    specialization: 'Orthopedics',
    experience: 18,
    rating: 4.7,
    image: 'https://images.pexels.com/photos/6749773/pexels-photo-6749773.jpeg?auto=compress&cs=tinysrgb&w=400',
    phone: '+1 (555) 567-8901',
    email: 'james.wilson@medcare.com',
    department: 'Orthopedics',
    qualifications: ['MD', 'Fellowship Trained', 'Board Certified'],
    languages: ['English'],
    shift: 'Morning'
  },
  {
    id: '6',
    name: 'Nurse Maria Garcia',
    role: 'Nurse',
    specialization: 'Emergency Care',
    experience: 10,
    rating: 4.8,
    image: 'https://images.pexels.com/photos/8460075/pexels-photo-8460075.jpeg?auto=compress&cs=tinysrgb&w=400',
    phone: '+1 (555) 678-9012',
    email: 'maria.garcia@medcare.com',
    department: 'Emergency',
    qualifications: ['RN', 'CEN', 'TNCC'],
    languages: ['English', 'Spanish'],
    shift: 'Evening'
  },
  {
    id: '7',
    name: 'Dr. Lisa Park',
    role: 'Doctor',
    specialization: 'Dermatology',
    experience: 9,
    rating: 4.9,
    image: 'https://images.pexels.com/photos/5407206/pexels-photo-5407206.jpeg?auto=compress&cs=tinysrgb&w=400',
    phone: '+1 (555) 789-0123',
    email: 'lisa.park@medcare.com',
    department: 'Dermatology',
    qualifications: ['MD', 'Board Certified', 'Fellowship Trained'],
    languages: ['English', 'Korean'],
    shift: 'Morning'
  },
  {
    id: '8',
    name: 'Nurse David Martinez',
    role: 'Nurse',
    specialization: 'Surgical Care',
    experience: 7,
    rating: 4.7,
    image: 'https://images.pexels.com/photos/8460089/pexels-photo-8460089.jpeg?auto=compress&cs=tinysrgb&w=400',
    phone: '+1 (555) 890-1234',
    email: 'david.martinez@medcare.com',
    department: 'Surgery',
    qualifications: ['RN', 'CNOR', 'BSN'],
    languages: ['English', 'Spanish'],
    shift: 'Night'
  }
];

export function StaffDirectory() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRole, setSelectedRole] = useState<string>('All');
  const [selectedDepartment, setSelectedDepartment] = useState<string>('All');
  const [selectedShift, setSelectedShift] = useState<string>('All');

  const roles = ['All', 'Doctor', 'Nurse'];
  const departments = ['All', ...Array.from(new Set(staffMembers.map(s => s.department)))];
  const shifts = ['All', 'Morning', 'Evening', 'Night'];

  const filteredStaff = staffMembers.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.specialization.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.department.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = selectedRole === 'All' || member.role === selectedRole;
    const matchesDepartment = selectedDepartment === 'All' || member.department === selectedDepartment;
    const matchesShift = selectedShift === 'All' || member.shift === selectedShift;
    
    return matchesSearch && matchesRole && matchesDepartment && matchesShift;
  });

  const getRoleColor = (role: string) => {
    return role === 'Doctor' ? 'text-blue-700 bg-blue-100' : 'text-teal-700 bg-teal-100';
  };

  const getShiftColor = (shift: string) => {
    switch (shift) {
      case 'Morning':
        return 'text-yellow-700 bg-yellow-100';
      case 'Evening':
        return 'text-orange-700 bg-orange-100';
      case 'Night':
        return 'text-purple-700 bg-purple-100';
      default:
        return 'text-gray-700 bg-gray-100';
    }
  };

  const totalDoctors = staffMembers.filter(s => s.role === 'Doctor').length;
  const totalNurses = staffMembers.filter(s => s.role === 'Nurse').length;
  const averageRating = (staffMembers.reduce((sum, s) => sum + s.rating, 0) / staffMembers.length).toFixed(1);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
          <Users className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Medical Staff Directory</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Meet our experienced doctors and nurses dedicated to your healthcare
        </p>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-200">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600 mb-2">{totalDoctors}</div>
            <div className="text-gray-600">Doctors</div>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-200">
          <div className="text-center">
            <div className="text-3xl font-bold text-teal-600 mb-2">{totalNurses}</div>
            <div className="text-gray-600">Nurses</div>
          </div>
        </div>
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-200">
          <div className="text-center">
            <div className="text-3xl font-bold text-purple-600 mb-2">{averageRating}</div>
            <div className="text-gray-600">Average Rating</div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-200 mb-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          <div className="lg:col-span-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search by name, specialization..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Role</label>
            <select
              value={selectedRole}
              onChange={(e) => setSelectedRole(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              {roles.map(role => (
                <option key={role} value={role}>{role}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Department</label>
            <select
              value={selectedDepartment}
              onChange={(e) => setSelectedDepartment(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              {departments.map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Shift</label>
            <select
              value={selectedShift}
              onChange={(e) => setSelectedShift(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            >
              {shifts.map(shift => (
                <option key={shift} value={shift}>{shift}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Staff Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredStaff.map((member) => (
          <div
            key={member.id}
            className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-200 hover:shadow-lg hover:border-purple-300 transition-all duration-200"
          >
            <div className="flex items-start space-x-4 mb-4">
              <img
                src={member.image}
                alt={member.name}
                className="w-20 h-20 rounded-xl object-cover"
              />
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">{member.name}</h3>
                    <p className="text-purple-600 font-medium">{member.specialization}</p>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm font-medium text-gray-700">{member.rating}</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 mt-2">
                  <span className={`px-2 py-1 rounded-lg text-xs font-medium ${getRoleColor(member.role)}`}>
                    {member.role}
                  </span>
                  <span className={`px-2 py-1 rounded-lg text-xs font-medium ${getShiftColor(member.shift)}`}>
                    {member.shift}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-500 mb-1">Experience</p>
                <p className="text-sm font-medium text-gray-900">{member.experience} years</p>
              </div>

              <div>
                <p className="text-sm text-gray-500 mb-1">Department</p>
                <p className="text-sm font-medium text-gray-900">{member.department}</p>
              </div>

              <div>
                <p className="text-sm text-gray-500 mb-1">Qualifications</p>
                <div className="flex flex-wrap gap-1">
                  {member.qualifications.map((qual) => (
                    <span key={qual} className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs">
                      {qual}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-sm text-gray-500 mb-1">Languages</p>
                <p className="text-sm font-medium text-gray-900">
                  {member.languages.join(', ')}
                </p>
              </div>

              <div className="pt-4 border-t border-gray-100 space-y-2">
                <div className="flex items-center space-x-3">
                  <Phone className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-gray-600">{member.phone}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-gray-600">{member.email}</span>
                </div>
              </div>

              <button className="w-full mt-4 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-200">
                View Profile
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredStaff.length === 0 && (
        <div className="text-center py-12">
          <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">No staff members found matching your criteria</p>
        </div>
      )}
    </div>
  );
}