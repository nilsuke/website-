import React from 'react';
import { Activity, MapPin, Phone, Mail, Clock } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gradient-to-r from-gray-900 via-blue-900 to-teal-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-gradient-to-r from-blue-600 to-teal-600 rounded-xl">
                <Activity className="h-8 w-8 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold">MedCare</h3>
                <p className="text-sm text-gray-300">Advanced Healthcare</p>
              </div>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              Experience the future of healthcare with our comprehensive digital platform 
              designed for seamless patient care and medical management.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Emergency Services</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Patient Portal</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Insurance Information</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Visitor Guidelines</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Medical Records</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Our Services</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Medicine Delivery</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Video Consultations</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Ward Bookings</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Lab Reports</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Specialist Care</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Information</h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-blue-400 mt-0.5" />
                <div>
                  <p className="text-gray-300">123 Healthcare Avenue</p>
                  <p className="text-gray-300">Medical District, MD 12345</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-blue-400" />
                <p className="text-gray-300">+1 (555) 123-CARE</p>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-blue-400" />
                <p className="text-gray-300">info@medcare.com</p>
              </div>
              <div className="flex items-start space-x-3">
                <Clock className="h-5 w-5 text-blue-400 mt-0.5" />
                <div>
                  <p className="text-gray-300">Emergency: 24/7</p>
                  <p className="text-gray-300">General: 6 AM - 10 PM</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2025 MedCare Advanced Healthcare. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Terms of Service</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Accessibility</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}