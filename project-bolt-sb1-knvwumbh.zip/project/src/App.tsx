import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { MedicineBooking } from './components/MedicineBooking';
import { DoctorConsultation } from './components/DoctorConsultation';
import { WardInfo } from './components/WardInfo';
import { StaffDirectory } from './components/StaffDirectory';
import { Footer } from './components/Footer';

type Section = 'home' | 'medicine' | 'consultation' | 'wards' | 'staff';

function App() {
  const [activeSection, setActiveSection] = useState<Section>('home');

  const renderSection = () => {
    switch (activeSection) {
      case 'home':
        return <Hero onNavigate={setActiveSection} />;
      case 'medicine':
        return <MedicineBooking />;
      case 'consultation':
        return <DoctorConsultation />;
      case 'wards':
        return <WardInfo />;
      case 'staff':
        return <StaffDirectory />;
      default:
        return <Hero onNavigate={setActiveSection} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-teal-50">
      <Header activeSection={activeSection} onNavigate={setActiveSection} />
      <main className="pt-20">
        {renderSection()}
      </main>
      <Footer />
    </div>
  );
}

export default App;